import os
import sys
import pickle
import numpy as np
from tqdm import tqdm
from collections import defaultdict
from sklearn.model_selection import StratifiedShuffleSplit


root = './'
data_dir = os.path.join(root, 'data')
batch_dir = os.path.join(root, 'criteo-batches-py')
processed_csv = 'processed_criteo.csv'

train_size=45840617
n_dense=13
n_sparse=26
thr=200

def dump(data, path):
    with open(path, 'wb') as f:
        pickle.dump(data, f)


def load(path):
    with open(path, 'rb') as f:
        data = pickle.load(f)
    return data


def process(dense_clip=None):
    if not os.path.isdir(data_dir):
        os.mkdir(data_dir)

    if dense_clip is None:
        dense_clip = [20, 600, 100, 50, 64000, 500, 100, 50, 500, 10, 10, 10, 50]

    raw_path = os.path.join(data_dir, 'raw', 'train.txt')
    if not os.path.exists(raw_path):
        sys.exit('Location of train.txt is invalid and should be: {}'.format(raw_path))

    dict_path = os.path.join(data_dir, 'category_dicts.pkl')
    if os.path.isfile(dict_path):
        print('Category Dicts already exists.')
        dicts = load(dict_path)
    else:
        print('Generating Dictionary (Counting Categories)...')
        counts = [defaultdict(int) for _ in range(n_sparse)]
        with open(os.path.join(raw_path), 'r') as f:
            for _ in tqdm(range(train_size)):
                features = f.readline().rstrip('\n').split('\t')
                sparse_features = features[n_dense + 1:]
                for sparse_feature, count in zip(sparse_features, counts):
                    if sparse_feature != '':
                        count[sparse_feature] += 1
        counts = [{k: v for k, v in count.items() if v >= thr} for count in counts]
        counts = [sorted(count.items(), key=lambda x: (-x[1], x[0])) for count in counts]
        dicts = [dict(zip(count, range(1, len(count) + 1))) for count in counts]
        for dic in dicts:
            dic['<unk>'] = 0
        dump(dicts, dict_path)

    if not os.path.isdir(batch_dir):
        os.mkdir(batch_dir)
    feature_sizes = ['1' for _ in range(n_dense)]
    feature_sizes.extend([str(len(dic)) for dic in dicts])
    with open(os.path.join(batch_dir, 'feature_sizes.csv'), 'w') as f:
        f.write(','.join(feature_sizes))
    print('{} has been made.'.format(os.path.join(batch_dir, 'feature_sizes.csv')))

    out_path = os.path.join(data_dir, processed_csv)
    if os.path.isfile(out_path):
        print('{} already exists...'.format(out_path))
    else:
        print('Processing Raw Data...')
        with open(out_path, 'w') as f_out:
            with open(os.path.join(raw_path), 'r') as f:
                for _ in tqdm(range(train_size)):
                    # Reading
                    features = f.readline().rstrip('\n').split('\t')
                    target = str(features[0])
                    dense = features[1: n_dense + 1]
                    sparse = features[n_dense + 1:]

                    # Processing
                    dense = [str(min(int(d), dc)) if d != '' else '0' for d, dc in zip(dense, dense_clip)]
                    sparse = [d[s] if s in d else 0 for s, d in zip(sparse, dicts)]
                    dense = ','.join(dense)
                    sparse = ','.join(list(map(str, sparse)))
                    f_out.write(','.join([target, dense, sparse]) + '\n')

                
def split_data():
    with open(os.path.join(data_dir, processed_csv), 'r') as f:
        data = np.array([list(map(int, f.readline().rstrip('\n').split(','))) for _ in tqdm(range(train_size))])
    y, X = np.hsplit(data, [1])
    print(X.shape)    
    print(y.shape)
   
    if not os.path.isdir(batch_dir):
        os.mkdir(batch_dir)
        print('{} was made.'.format(batch_dir))
            
    print('Splitting train and test...')
    np.random.seed(0)
    sss = StratifiedShuffleSplit(train_size=0.9, random_state=0)
    for indices in sss.split(X, y):
        train_index, test_index = indices
        print('Splitting train to some batches...')
        index_list = np.array_split(train_index, 9, axis=0)
        index_list.append(test_index)

        print("Dumping...")
        data = np.hstack([y, X])
        for i, index in tqdm(enumerate(index_list)):
            dump(data[index], os.path.join(batch_dir, 'data_batch_{}'.format(i)))
        break
        

if __name__ == '__main__':
    process()
    split_data()
