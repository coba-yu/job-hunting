import os
import sys
import random
import pickle
import requests
import numpy as np
from argparse import ArgumentParser
from tqdm import tqdm
from time import time
from sklearn.metrics import accuracy_score, roc_auc_score
import torch
from torch.utils.data import DataLoader
from torch import sigmoid
from torch.nn.functional import binary_cross_entropy_with_logits
from torch.optim import Adam, Adagrad, RMSprop
from optimizer.coba import CoBAHZ, CoBAFR, CoBAHS, CoBAPRP, CoBADY
from model import DeepFM
from dataset import CriteoDataset


def prepare_data(root: str, data: str, bs: int, nw: int=16):
    if data == 'Criteo':
        train_data = CriteoDataset(root, train=True)
        test_data = CriteoDataset(root, train=False)
    else:
        sys.exit('data is invalid...')

    def worker_init_fn(worker_id):
        random.seed(worker_id)
    
    train_loader = DataLoader(train_data, batch_size=bs, shuffle=True, num_workers=nw, worker_init_fn=worker_init_fn)
    test_loader = DataLoader(test_data, batch_size=bs, shuffle=False, num_workers=nw, worker_init_fn=worker_init_fn)
    return train_loader, test_loader, train_data.feature_sizes


def train(net, train_loader, test_loader, optimizer, device,
          loss_fn=binary_cross_entropy_with_logits, max_epoch: int=100, save_name: str=None) -> dict:
    train_loss = []
    train_auc = [] 
    train_acc = []
    test_loss = []
    test_auc = []
    test_acc = []
    times = []
    for epoch in tqdm(range(max_epoch)):
        # Train
        running_loss = 0.0
        net.train()
        start = time()
        ys = []
        y_preds = []
        i = 0
        for xi, xv, y in tqdm(train_loader, desc='Epoch {}'.format(epoch)):
            xi = xi.to(device, dtype=torch.long)
            xv = xv.to(device, dtype=torch.float)
            y = y.to(device, dtype=torch.float)
            h = net(xi, xv)
            loss = loss_fn(h, y)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
            ys.extend(y.tolist())
            y_preds.extend(sigmoid(h).tolist())
            i += 1
        times.append(time() - start)
        train_loss.append(running_loss / i)
        # 損失がnanになったら終了
        if np.isnan(running_loss):
            break
        ys = np.array(ys)
        y_preds = np.array(y_preds)
        acc1 = accuracy_score(ys, np.where(y_preds > 0.5, 1, 0))
        auc1 = roc_auc_score(ys, y_preds)
        print('Loss', running_loss / i, 'Acc.', acc1, 'AUC', auc1)
        train_acc.append(acc1)
        train_auc.append(auc1)

        # Test
        running_loss = 0.0
        net.eval()
        ys = []
        y_preds = []
        i = 0
        for xi, xv, y in tqdm(train_loader, desc='Epoch {}'.format(epoch)):
            xi = xi.to(device, dtype=torch.long)
            xv = xv.to(device, dtype=torch.float)
            y = y.to(device, dtype=torch.float)
            h = net(xi, xv)
            loss = loss_fn(h, y)
            running_loss += loss.item()
            ys.extend(y.tolist())
            y_preds.extend(sigmoid(h).tolist())
            i += 1
        test_loss.append(running_loss / i)
        ys = np.array(ys)
        y_preds = np.array(y_preds)
        acc2 = accuracy_score(ys, np.where(y_preds > 0.5, 1, 0))
        auc2 = roc_auc_score(ys, y_preds)
        print('Loss', running_loss / i, 'Acc.', acc2, 'AUC', auc2)
        test_acc.append(acc2)
        test_auc.append(auc2)

    if save_name is not None:
        with open(save_name, 'wb') as f:
            pickle.dump(net, f)

    return {'train_loss': train_loss, 'train_acc': train_acc, 'train_auc': train_auc,
            'test_loss': test_loss, 'test_acc': test_acc, 'test_auc': test_auc,
            'time': times}


def dump(data, path):
    with open(path, 'wb') as f:
        pickle.dump(data, f)


def load(path):
    with open(path, 'rb') as f:
        data = pickle.load(f)
    return data


def line(message='実験終了', image=None, result=None):
    url = 'https://notify-api.line.me/api/notify'
    token = 'n8SFnrhDd9zSHAWgeM4NHAEW6AJItrqtKxKdiuSr8sx' #ここにアクセストークンを入力します。
    headers = {'Authorization' : 'Bearer '+ token}

    m = message[:]
    payload = {'message' :  m}
    r = requests.post(url, headers=headers, params=payload)


def main():
    random.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)
    torch.cuda.manual_seed(0)
    torch.backends.cudnn.deterministic = True

    # Read command line arguments
    parser = ArgumentParser()
    parser.add_argument('--batch_size', type=int, default=32768)
    parser.add_argument('--num_workers', type=int, default=16)
    parser.add_argument('--max_epoch', type=int, default=30)
    parser.add_argument('--data', type=str, default='Criteo')
    parser.add_argument('--model', type=str, default='DeepFM')
    parser.add_argument('--root', type=str, default='./')
    parser.add_argument('--device', type=str, default=None)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--m', type=float, default=1e-4)
    parser.add_argument('--a', type=float, default=1e-5)

    args = parser.parse_args()
    batch_size = args.batch_size
    num_workers = args.num_workers
    max_epoch = args.max_epoch
    data = args.data
    model = args.model
    root = args.root
    device = args.device
    lr = args.lr
    m = args.m
    a = args.a

    path = os.path.join(root, data)
    if not os.path.exists(path):
        os.mkdir(root)
    path = os.path.join(path, model)
    if not os.path.exists(path):
        os.mkdir(path)
    lr_dic = {1e-2: 'lr2', 1e-3: 'lr3', 1e-4: 'lr4'}
    path = os.path.join(path, lr_dic[lr])
    if not os.path.exists(path):
        os.mkdir(path)
    if not os.path.exists(os.path.join(path, 'model')):
        os.mkdir(os.path.join(path, 'model'))
    
    print(args)
    with open(os.path.join(path, 'args.txt'), 'w') as f:
        f.write(str(args))

    # Preparing dataset
    train_loader, test_loader, feature_sizes = prepare_data(root, data, batch_size, num_workers)
    print('Dataset was prepared.')

    # Optimizer
    optim_dic = {#'Adam': Adam,
                 'CoBA(HZ)': CoBAHZ,
                 'AMSGrad': Adam, 
                 'Adam': Adam,
                 'AdaGrad': Adagrad, 
                 'RMSProp': RMSprop,
                 'CoBA(FR)': CoBAFR, 
                 'CoBA(HS)': CoBAHS,
                 'CoBA(PRP)': CoBAPRP, 
                 'CoBA(DY)': CoBADY
                }

    if device is None:
        if torch.cuda.is_available():
            device = 'cuda:0'
            print('Using GPU...')
        else:
            device = 'cpu'
            print('Using CPU...')

    for k in optim_dic:
        print(k)
        random.seed(0)
        np.random.seed(0)
        torch.manual_seed(0)
        torch.cuda.manual_seed(0)
        torch.backends.cudnn.deterministic = True

        # Build model
        net = DeepFM(feature_sizes)
        net.to(device)

        # Optimizer
        if k[:4] == 'CoBA':
            optimizer = optim_dic[k](net.parameters(), lr, m=m, a=a)
        elif k == 'AMSGrad':
            optimizer = optim_dic[k](net.parameters(), lr, amsgrad=True)
        else:
            optimizer = optim_dic[k](net.parameters(), lr)

        result = train(net, train_loader, test_loader, optimizer,
                       max_epoch=max_epoch, device=device)
        dump(result, os.path.join(path, '{}.pkl'.format(k)))
        line(k)


if __name__ == '__main__':
    main()
    line()
