# 201910-coba-ctr

## Usage

1. Please download Criteo dataset  
  [Kaggle Display Advertising Challenge Dataset](http://labs.criteo.com/2014/02/kaggle-display-advertising-challenge-dataset/)
