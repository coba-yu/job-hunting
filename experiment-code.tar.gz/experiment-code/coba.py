import math
import torch
from torch.optim import Optimizer


class CoBA(Optimizer):
    """Implements CoBA(Conjugate-gradient-Based Adam) algorithm.

    Arguments:
        params (iterable): 最適化するパラメータ
        defaults (dict):
    """

    def __init__(self, params, defaults):
        super(CoBA, self).__init__(params, defaults)

    def __setstate__(self, state):
        super(CoBA, self).__setstate__(state)
        for group in self.param_groups:
            group.setdefault('amsgrad', True)

    def compute_gamma(self, grad, p_grad, p_cgrad, group):
        raise NotImplementedError

    def step(self, closure=None):
        """更新一回分の機能

        Arguments:
            closure (callable, optional): モデルを再評価し損失を返すクロージャ
        """

        loss = None  # 損失の初期化
        if closure is not None:
            loss = closure()  # 損失のクロージャが指定されていれば設定

        compute_gamma = self.compute_gamma

        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None:
                    continue  # 勾配が計算されていなければスキップ
                grad = p.grad.data  # 勾配を取得
                if grad.is_sparse:  # 勾配が疎であればエラー
                    raise RuntimeError('CoBA does not support sparce gradients, please consider SparseAdam instead')

                amsgrad = group['amsgrad']
                state = self.state[p]  # 直前に保存した更新に用いるパラメータ

                # 直前に保存した更新に用いるパラメータがない(長さが0)ならば初期化
                if len(state) == 0:
                    state['step'] = 0  # 更新した回数はまだ0回
                    state['exp_avg'] = torch.zeros_like(p.data)  # 勾配の指数移動平均
                    state['exp_avg_sq'] = torch.zeros_like(p.data)  # 勾配の指数移動平均の平方
                    if amsgrad:
                        state['max_exp_avg_sq'] = torch.zeros_like(p.data)  # 勾配の指数移動平均の平方の最大値
                    state['past_grad'] = None
                    state['conjugate_grad'] = None

                if state['past_grad'] is None:
                    state['conjugate_grad'] = grad.clone()
                    state['past_grad'] = grad.clone()

                else:
                    p_grad = state['past_grad']
                    p_cgrad = state['conjugate_grad']
                    gamma = compute_gamma(grad, p_grad, p_cgrad, group)
                    gamma.mul_(group['m'] / state['step'] ** (1 + group['a']))
                    state['conjugate_grad'] = grad - gamma * p_cgrad
                    state['past_grad'].copy_(grad)

                exp_avg, exp_avg_sq = state['exp_avg'], state['exp_avg_sq']
                if amsgrad:
                    max_exp_avg_sq = state['max_exp_avg_sq']
                beta1, beta2 = group['betas']

                state['step'] += 1  # 更新した回数を増やす4
                if group['weight_decay'] != 0:
                    grad.add_(group['weight_decay'], p.data)  # 重み減衰 (正則化)

                exp_avg.mul_(beta1).add_(1 - beta1, state['conjugate_grad'])  # m
                exp_avg_sq.mul_(beta2).addcmul_(1 - beta2, grad, grad)
                if amsgrad:
                    torch.max(max_exp_avg_sq, exp_avg_sq, out=max_exp_avg_sq)  # 勾配の指数移動平均の平方の最大値を更新
                    denom = max_exp_avg_sq.sqrt().add_(group['eps'])
                else:
                    denom = exp_avg_sq.sqrt().add_(group['eps'])

                bias_correction1 = 1 - beta1 ** state['step']
                bias_correction2 = 1 - beta2 ** state['step']
                step_size = group['lr'] * math.sqrt(bias_correction2) / bias_correction1
                p.data.addcdiv_(-step_size, exp_avg, denom)

        return loss


class CoBAHZ(CoBA):
    """Implements CoBA(Conjugate-gradient-Based Adam) algorithm.

    Arguments:
        params (iterable): 最適化するパラメータ
        lr (float, optional): 学習率 (default: 1e-3)
        betas (Tuple[float, float], optional): 勾配の移動平均とその平方根に対応する係数 (default: (0.9, 0.999))
        eps (float, optional): 数値安定性を保証するために分母に加える値 (default: 1e-8)
        weight_decay (float, optional): 重み減衰 (L2正則化) (default: 0)
        amsgrad (boolean, optional): AMSGradを適応するか (default: True)
        eta (float, optional): (default: 1e-2)
        lam (float, optional): (default: 2.0)
        m (float, optional): (default: 1e-4)
        a (float, optional): (default: 1e-5)
    """

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                 weight_decay=0, amsgrad=True, eta=1e-2, lam=2.0, m=1e-4, a=1e-5):
        defaults = dict(lr=lr, betas=betas, eps=eps,
                        weight_decay=weight_decay, amsgrad=amsgrad,
                        lam=lam, eta=eta, m=m, a=a)
        super().__init__(params, defaults)
        self.name = 'CoBA(HZ)'

    def compute_gamma(self, grad, past, d, group):
        def inner(a, b):
            return (a * b).sum(-1, keepdim=True)

        y = grad - past
        dy = inner(d, y)
        eps = torch.full_like(dy, group['eps'])
        dy = torch.where(((dy >= 0) & (dy < group['eps'])), eps, dy)
        dy = torch.where(((dy < 0) & (dy > -group['eps'])), -eps, dy)
        gamma = inner(grad, y) / dy
        gamma.add_(- group['lam'] * inner(y, y) * inner(grad, d) / dy ** 2)
        eta = -1 / (inner(d, d) * torch.min(inner(past, past), torch.full_like(gamma, group['eta'])))
        torch.max(gamma, eta, out=gamma)
        return gamma


class CoBAHS(CoBA):
    """Implements CoBA(Conjugate-gradient-Based Adam) algorithm.

    Arguments:
        params (iterable): 最適化するパラメータ
        lr (float, optional): 学習率 (default: 1e-3)
        betas (Tuple[float, float], optional): 勾配の移動平均とその平方根に対応する係数 (default: (0.9, 0.999))
        eps (float, optional): 数値安定性を保証するために分母に加える値 (default: 1e-8)
        weight_decay (float, optional): 重み減衰 (L2正則化) (default: 0)
        amsgrad (boolean, optional): AMSGradを適応するか (default: True)
        m (float, optional): (defalut: 1e-4)
        a (float, optional): (defalut: 1e-5)
    """

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                 weight_decay=0, amsgrad=True, m=1e-4, a=1e-5):
        defaults = dict(lr=lr, betas=betas, eps=eps,
                        weight_decay=weight_decay, amsgrad=amsgrad, m=m, a=a)
        super().__init__(params, defaults)
        self.name = 'CoBA(HS)'

    def __setstate__(self, state):
        super().__setstate__(state)
        for group in self.param_groups:
            group.setdefault('amsgrad', True)
            group.setdefault('m', 1e-4)
            group.setdefault('a', 1e-5)

    def compute_gamma(self, grad, past, d, group):
        def inner(a, b):
            return (a * b).sum(-1, keepdim=True)
        y = grad - past
        dy = inner(d, y)
        eps = torch.full_like(dy, group['eps'])
        dy = torch.where(((dy >= 0) & (dy < group['eps'])), eps, dy)
        dy = torch.where(((dy < 0) & (dy > -group['eps'])), -eps, dy)
        return inner(grad, y) / dy


class CoBAFR(CoBA):
    """Implements CoBA(Conjugate-gradient-Based Adam) algorithm.

    Arguments:
        params (iterable): 最適化するパラメータ
        lr (float, optional): 学習率 (default: 1e-3)
        betas (Tuple[float, float], optional): 勾配の移動平均とその平方根に対応する係数 (default: (0.9, 0.999))
        eps (float, optional): 数値安定性を保証するために分母に加える値 (default: 1e-8)
        weight_decay (float, optional): 重み減衰 (L2正則化) (default: 0)
        amsgrad (boolean, optional): AMSGradを適応するか (default: True)
        m (float, optional): (defalut: 1e-4)
        a (float, optional): (defalut: 1e-5)
    """

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                 weight_decay=0, amsgrad=True, m=1e-4, a=1e-5):
        defaults = dict(lr=lr, betas=betas, eps=eps,
                        weight_decay=weight_decay, amsgrad=amsgrad, m=m, a=a)
        super().__init__(params, defaults)
        self.name = 'CoBA(FR)'

    def compute_gamma(self, grad, past, d, group):
        def inner(a, b):
            return (a * b).sum(-1, keepdim=True)
        p_norm = inner(past, past)
        eps = torch.full_like(p_norm, group['eps'])
        p_norm = torch.where(((p_norm >= 0) & (p_norm < group['eps'])), eps, p_norm)
        return inner(grad, grad) / p_norm


class CoBAPRP(CoBA):
    """Implements CoBA(Conjugate-gradient-Based Adam) algorithm.

    Arguments:
        params (iterable): 最適化するパラメータ
        lr (float, optional): 学習率 (default: 1e-3)
        betas (Tuple[float, float], optional): 勾配の移動平均とその平方根に対応する係数 (default: (0.9, 0.999))
        eps (float, optional): 数値安定性を保証するために分母に加える値 (default: 1e-8)
        weight_decay (float, optional): 重み減衰 (L2正則化) (default: 0)
        amsgrad (boolean, optional): AMSGradを適応するか (default: True)
        m (float, optional): (defalut: 1e-4)
        a (float, optional): (defalut: 1e-5)
    """

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                 weight_decay=0, amsgrad=True, m=1e-4, a=1e-5):
        defaults = dict(lr=lr, betas=betas, eps=eps,
                        weight_decay=weight_decay, amsgrad=amsgrad, m=m, a=a)
        super().__init__(params, defaults)
        self.name = 'CoBA(PRP)'

    def compute_gamma(self, grad, past, d, group):
        def inner(a, b):
            return (a * b).sum(-1, keepdim=True)
        y = grad - past
        p_norm = inner(past, past)
        eps = torch.full_like(p_norm, group['eps'])
        p_norm = torch.where(((p_norm >= 0) & (p_norm < group['eps'])), eps, p_norm)
        return inner(grad, y) / p_norm



class CoBADY(CoBA):
    """Implements CoBA(Conjugate-gradient-Based Adam) algorithm.

    Arguments:
        params (iterable): 最適化するパラメータ
        lr (float, optional): 学習率 (default: 1e-3)
        betas (Tuple[float, float], optional): 勾配の移動平均とその平方根に対応する係数 (default: (0.9, 0.999))
        eps (float, optional): 数値安定性を保証するために分母に加える値 (default: 1e-8)
        weight_decay (float, optional): 重み減衰 (L2正則化) (default: 0)
        amsgrad (boolean, optional): AMSGradを適応するか (default: True)
        m (float, optional): (defalut: 1e-4)
        a (float, optional): (defalut: 1e-5)
    """

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                 weight_decay=0, amsgrad=True, m=1e-4, a=1e-5):
        defaults = dict(lr=lr, betas=betas, eps=eps,
                        weight_decay=weight_decay, amsgrad=amsgrad, m=m, a=a)
        super().__init__(params, defaults)
        self.name = 'CoBA(DY)'

    def compute_gamma(self, grad, past, d, group):
        def inner(a, b):
            return (a * b).sum(-1, keepdim=True)
        y = grad - past
        dy = inner(d, y)
        eps = torch.full_like(dy, group['eps'])
        dy = torch.where(((dy >= 0) & (dy < group['eps'])), eps, dy)
        dy = torch.where(((dy < 0) & (dy > -group['eps'])), -eps, dy)
        return inner(grad, grad) / dy
