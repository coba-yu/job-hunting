import os
import sys
import random
import pickle
import numpy as np
from argparse import ArgumentParser
from tqdm import tqdm
from time import time
import torch
from torch.utils.data import DataLoader
from torchvision.datasets import CIFAR10, CIFAR100, FashionMNIST, ImageNet
from torchvision.transforms import ToTensor
from torchvision.models import resnet18, resnet34, resnet50, resnet101, resnet152
from torch.optim import Adam, Adagrad, RMSprop
from optimizer.coba import CoBAHZ, CoBAFR, CoBAHS, CoBAPRP, CoBADY


def prepare_data(root: str, data: str, bs: int=128):
    if data == 'CIFAR10':
        train_data = CIFAR10(root, train=True, download=True, transform=ToTensor())
        test_data = CIFAR10(root, train=False, download=True, transform=ToTensor())
    elif data == 'CIFAR100':
        train_data = CIFAR100(root, train=True, download=True, transform=ToTensor())
        test_data = CIFAR100(root, train=False, download=True, transform=ToTensor())
    elif data == 'FashionMNIST':
        train_data = FashionMNIST(root, train=True, download=True, transform=ToTensor())
        test_data = FashionMNIST(root, train=True, download=True, transform=ToTensor())
    elif data == 'ImageNet':
        train_data = ImageNet(root, train=True, download=True, transform=ToTensor())
        test_data = ImageNet(root, train=True, download=True, transform=ToTensor())
    else:
        sys.exit('data is invalid...')

    train_loader = DataLoader(train_data, batch_size=bs, shuffle=True)
    test_loader = DataLoader(test_data, batch_size=bs, shuffle=False)
    return train_loader, test_loader


def choice_model(model: str):
    if model == 'resnet18':
        return resnet18()
    elif model == 'resnet34':
            return resnet34()
    elif model == 'resnet50':
            return resnet50()
    elif model == 'resnet101':
            return resnet101()
    elif model == 'resnet152':
            return resnet152()
    else:
        sys.exit('model is invalid...')


def eval_net(net, data_loader, device):
    net.eval()  # DropoutやBatchNormを無効化
    ys = []  # 正解
    y_preds = []  # 予測値
    for x, y in data_loader:
        x = x.to(device)  # 転送
        y = y.to(device)
        with torch.no_grad():  # 自動微分をオフ
            _, y_pred = net(x).max(1)  # 確率が最大のクラスを予測
        ys.append(y)
        y_preds.append(y_pred)

    ys = torch.cat(ys)  # ミニバッチごとの結果をまとめる
    y_preds = torch.cat(y_preds)

    acc = (ys == y_preds).float().sum() / len(ys)  # 予測精度
    return acc.item()


def train(net, train_loader, test_loader, optimizer, device,
          loss_fn=torch.nn.CrossEntropyLoss(), max_epoch: int=200, save_name: str=None) -> dict:
    losses = []  # 損失
    train_acc = []  # 訓練精度
    val_acc = []  # 評価精度
    times = []
    for epoch in tqdm(range(max_epoch)):
        running_loss = 0.0
        net.train()
        n = 0
        n_acc = 0
        start = time()
        for i, (xx, yy) in tqdm(enumerate(train_loader), desc='Epoch {}'.format(epoch)):
            xx = xx.to(device)
            yy = yy.to(device)
            h = net(xx)
            loss = loss_fn(h, yy)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
            n += len(xx)
            _, y_pred = h.max(1)
            n_acc += (yy == y_pred).float().sum().item()  # 予測精度
        times.append(time() - start)
        losses.append(running_loss / i)

        # 損失がnanになったら終了
        if np.isnan(running_loss):
            break
        train_acc.append(n_acc / n)
        val_acc.append(eval_net(net, test_loader, device))

    if save_name is not None:
        with open(save_name, 'wb') as f:
            pickle.dump(net, f)

    return {'loss': losses, 'train': train_acc, 'eval': val_acc, 'time': times}


def dump(data, path):
    with open(path, 'wb') as f:
        pickle.dump(data, f)


def load(path):
    with open(path, 'rb') as f:
        data = pickle.load(f)
    return data


def main():
    random.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)
    torch.cuda.manual_seed(0)
    torch.backends.cudnn.deterministic = True

    # Read command line arguments
    parser = ArgumentParser()
    parser.add_argument('--batch_size', type=int, default=128)
    parser.add_argument('--max_epoch', type=int, default=200)
    parser.add_argument('--data', type=str, default='CIFAR10')
    parser.add_argument('--model', type=str, default='resnet152')
    parser.add_argument('--root', type=str, default='./')
    parser.add_argument('--device', type=str, default=None)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--m', type=float, default=1e-4)
    parser.add_argument('--a', type=float, default=1e-5)

    args = parser.parse_args()
    batch_size = args.batch_size
    max_epoch = args.max_epoch
    data = args.data
    model = args.model
    root = args.root
    device = args.device
    lr = args.lr
    m = args.m
    a = args.a

    path = os.path.join(root, data)
    if not os.path.exists(path):
        os.mkdir(path)
    path = os.path.join(path, model)
    if not os.path.exists(path):
        os.mkdir(path)
    lr_dic = {1e-2: 'lr2', 1e-3: 'lr3', 1e-4: 'lr4'}
    path = os.path.join(path, lr_dic[lr])
    if not os.path.exists(path):
        os.mkdir(path)
    if not os.path.exists(os.path.join(path, 'model')):
        os.mkdir(os.path.join(path, 'model'))
    
    print(args)
    with open(os.path.join(path, 'args.txt'), 'w') as f:
        f.write(str(args))

    # Preparing dataset
    train_loader, test_loader = prepare_data(root, data, batch_size)

    # Build model
    net = choice_model(model)
    if device is None:
        if torch.cuda.is_available():
            device = 'cuda:0'
            print('Using GPU...')
        else:
            device = 'cpu'
            print('Using CPU...')

    # Optimizer
    optim_dic = {'Adam': Adam, 
                 'AMSGrad': Adam, 
                 'AdaGrad': Adagrad, 
                 'RMSProp': RMSprop,
                 'CoBA(HZ)': CoBAHZ, 
                 #'CoBA(FR)': CoBAFR, 
                 #'CoBA(HS)': CoBAHS,
                 #'CoBA(PRP)': CoBAPRP, 
                 #'CoBA(DY)': CoBADY
                }

    for k in optim_dic:
        print(k)
        random.seed(0)
        np.random.seed(0)
        torch.manual_seed(0)
        torch.cuda.manual_seed(0)
        torch.backends.cudnn.deterministic = True

        # Build model
        net = choice_model(model)
        net.to(device)
        if k[:4] == 'CoBA':
            optimizer = optim_dic[k](net.parameters(), lr, m=m, a=a)
        elif k == 'AMSGrad':
            optimizer = optim_dic[k](net.parameters(), lr, amsgrad=True)
        else:
            optimizer = optim_dic[k](net.parameters(), lr)

        result = train(net, train_loader, test_loader, optimizer,
                       max_epoch=max_epoch, device=device)
        dump(result, os.path.join(path, '{}.pkl'.format(k)))


if __name__ == '__main__':
    main()
