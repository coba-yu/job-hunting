import os
import pickle
import numpy as np
from tqdm import tqdm
import torch
from torch.utils.data import Dataset


def load(path):
    with open(path, 'rb') as f:
        data = pickle.load(f)
    return data


class CriteoDataset(Dataset):
    def __init__(self, root='./', train=True, data_dir='criteo-batches-py'):
        self.root = root
        self.data_dir = data_dir
        if train:
            path_list = [os.path.join(root, data_dir, 'data_batch_{}'.format(i)) for i in range(9)]
            data = np.vstack([load(path) for path in tqdm(path_list, desc='Loading batches...')])
        else:
            data = load(os.path.join(root, data_dir, 'data_batch_9'))

        self.target, self.data = np.hsplit(data, [1])
        self.target = self.target.flatten()
        self.n_dense = 13
        self.feature_sizes = list(map(int, np.loadtxt(os.path.join(root, data_dir, 'feature_sizes.csv'), delimiter=',')))

    def __getitem__(self, idx):
        data_i = self.data[idx]
        target_i = self.target[idx]

        dense_idx = np.zeros_like(data_i[:self.n_dense])
        sparse_idx = data_i[self.n_dense:]
        xi = torch.from_numpy(np.concatenate((dense_idx, sparse_idx)).astype(np.int32)).unsqueeze(-1)
        
        dense_values = data_i[:self.n_dense]
        sparse_values = np.ones_like(data_i[self.n_dense:])
        xv = torch.from_numpy(np.concatenate((dense_values, sparse_values)).astype(np.int32))

        return xi, xv, target_i

    def __len__(self):
        return len(self.data)

    def __check_exists(self):
        return os.path.exists(os.path.join(self.root, self.data_dir))


if __name__ == '__main__':
    print('main is executed.')
    dataset = CriteoDataset()
    print(dataset.data)
    print(dataset.data.shape)
    print(dataset.target.shape)
    print(dataset[100])
    print(len(dataset))
